
#include	<gobject/gmarshal.h>

G_BEGIN_DECLS

/* VOID:STRING,POINTER (peditor-marshal.list:25) */
extern void cc_marshal_VOID__STRING_POINTER (GClosure     *closure,
					     GValue       *return_value,
					     guint         n_param_values,
					     const GValue *param_values,
					     gpointer      invocation_hint,
					     gpointer      marshal_data);

G_END_DECLS

