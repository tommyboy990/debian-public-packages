GNOME BT support for Cinnamon
