Nemo
====
File Manager for Cinnamon

Nemo is the file manager for the Cinnamon desktop environment. 
