./mocheck.py -po po-export

