#define NEW csd_orientation_manager_new
#define START csd_orientation_manager_start
#define STOP csd_orientation_manager_stop
#define MANAGER CsdOrientationManager
#include "csd-orientation-manager.h"

#include "test-plugin.h"
