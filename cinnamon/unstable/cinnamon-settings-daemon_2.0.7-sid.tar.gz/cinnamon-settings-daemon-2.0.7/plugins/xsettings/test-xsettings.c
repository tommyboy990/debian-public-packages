#define NEW cinnamon_xsettings_manager_new
#define START cinnamon_xsettings_manager_start
#define STOP cinnamon_xsettings_manager_stop
#define MANAGER CinnamonSettingsXSettingsManager
#include "csd-xsettings-manager.h"

#include "test-plugin.h"
