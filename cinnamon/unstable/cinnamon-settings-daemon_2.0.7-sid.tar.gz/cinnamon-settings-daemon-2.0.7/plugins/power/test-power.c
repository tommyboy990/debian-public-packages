#define NEW csd_power_manager_new
#define START csd_power_manager_start
#define STOP csd_power_manager_stop
#define MANAGER CsdPowerManager
#include "csd-power-manager.h"

#include "test-plugin.h"
