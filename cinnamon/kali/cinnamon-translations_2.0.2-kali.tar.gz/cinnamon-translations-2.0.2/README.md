1. Download MOs and POs from Launchpad
2. Replace the content of mo-export and po-export with the content of the two archives
3. run ./cleanup.sh
4. run ./check.sh
5. If everything is fine, build the package with dpkg-buildpackage
