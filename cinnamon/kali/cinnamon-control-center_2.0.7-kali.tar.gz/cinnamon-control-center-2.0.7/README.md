Settings need to be unified and consistent. At the moment configuration is split between an incomplete Cinnamon Settings and a heavily patched Gnome Control Center.

One of these two tools need to be removed from the default installation and discontinued in the scope of the Cinnamon project. The other one needs to be able to load all modules, whether they're GNOME modules or Cinnamon settings modules.

This git repository attempts to use Gnome Control Center as the start point for a unified control center.

Similar efforts might take place with Cinnamon Settings as a starting point.
