#define NEW csd_a11y_settings_manager_new
#define START csd_a11y_settings_manager_start
#define STOP csd_a11y_settings_manager_stop
#define MANAGER CsdA11ySettingsManager
#include "csd-a11y-settings-manager.h"

#include "test-plugin.h"
