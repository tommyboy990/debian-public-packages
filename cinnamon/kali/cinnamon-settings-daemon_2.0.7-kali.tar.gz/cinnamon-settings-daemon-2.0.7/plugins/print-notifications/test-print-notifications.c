#define NEW csd_print_notifications_manager_new
#define START csd_print_notifications_manager_start
#define STOP csd_print_notifications_manager_stop
#define MANAGER CsdPrintNotificationsManager
#include "csd-print-notifications-manager.h"

#include "test-plugin.h"
