// application/javascript;version=1.8
function testBasic1() {
    var foo = 1+1;
    assertEquals(2, foo);
}

gjstestRun();
