// application/javascript;version=1.8
const A = imports.mutualImport.a;

function getCount() {
    return A.getCount();
}

