#define NEW csd_sound_manager_new
#define START csd_sound_manager_start
#define STOP csd_sound_manager_stop
#define MANAGER CsdSoundManager
#include "csd-sound-manager.h"

#include "test-plugin.h"
