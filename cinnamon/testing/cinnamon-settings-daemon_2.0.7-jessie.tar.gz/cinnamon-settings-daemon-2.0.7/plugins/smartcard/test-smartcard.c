#define NEW csd_smartcard_manager_new_default
#define START csd_smartcard_manager_start
#define STOP csd_smartcard_manager_stop
#define MANAGER CsdSmartcardManager
#include "csd-smartcard-manager.h"

#include "test-plugin.h"
