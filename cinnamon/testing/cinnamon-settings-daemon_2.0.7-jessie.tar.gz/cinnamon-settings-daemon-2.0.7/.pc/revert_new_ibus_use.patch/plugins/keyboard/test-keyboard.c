#define NEW gsd_keyboard_manager_new
#define START gsd_keyboard_manager_start
#define STOP gsd_keyboard_manager_stop
#define MANAGER GsdKeyboardManager
#include "gsd-keyboard-manager.h"

#include "test-plugin.h"
