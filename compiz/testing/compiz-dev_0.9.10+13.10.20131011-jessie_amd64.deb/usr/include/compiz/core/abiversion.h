#ifndef COMPIZ_ABIVERSION_H
#define COMPIZ_ABIVERSION_H

#ifdef CORE_ABIVERSION
#  error Conflicting definitions of CORE_ABIVERSION
#endif

#define CORE_ABIVERSION 20130415

#endif // COMPIZ_ABIVERSION_H
