/*
 * Copyright © 2011 Canonical Ltd.
 * Copyright © 2008 Dennis Kasprzyk
 * Copyright © 2007 Novell, Inc.
 *
 * Permission to use, copy, modify, distribute, and sell this software
 * and its documentation for any purpose is hereby granted without
 * fee, provided that the above copyright notice appear in all copies
 * and that both that copyright notice and this permission notice
 * appear in supporting documentation, and that the name of
 * Dennis Kasprzyk not be used in advertising or publicity pertaining to
 * distribution of the software without specific, written prior permission.
 * Dennis Kasprzyk makes no representations about the suitability of this
 * software for any purpose. It is provided "as is" without express or
 * implied warranty.
 *
 * DENNIS KASPRZYK DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 * INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN
 * NO EVENT SHALL DENNIS KASPRZYK BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT,
 * NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION
 * WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * Authors: Dennis Kasprzyk <onestone@compiz-fusion.org>
 *          David Reveman <davidr@novell.com>
 */

#ifndef _COMPWINDOWEXTENTS_H
#define _COMPWINDOWEXTENTS_H

#include <core/point.h>

namespace compiz
{
namespace window
{
namespace extents
{
/**
 * Specifies the left, right, top and bottom positions of a window's
 * geometry
 */
class Extents
{
    public:

	Extents ();
	Extents (int left, int right, int top, int bottom);

	int left;
	int right;
	int top;
	int bottom;

	bool operator== (const Extents &other) const;
	bool operator!= (const Extents &other) const;

	/* Only here for ABI compatability */
	bool operator== (const Extents &other);
	bool operator!= (const Extents &other);
};

CompPoint shift (const Extents &extents,
		 unsigned int  gravity = 0);
}
}
}

typedef compiz::window::extents::Extents CompWindowExtents;

#endif
